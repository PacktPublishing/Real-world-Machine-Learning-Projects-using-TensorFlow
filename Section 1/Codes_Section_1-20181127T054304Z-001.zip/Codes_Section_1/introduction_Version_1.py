
# coding: utf-8

# In[1]:


import tensorflow as tf
import numpy as np
import pandas 


# In[2]:


print ( "Mession Done")


# In[3]:


from __future__ import absolute_import 
from __future__ import division
from __future__ import print_function
from keras.callbacks import TensorBoard


# In[4]:


from __future__ import absolute_import 
from __future__ import division
from __future__ import print_function
from keras.callbacks import TensorBoard


# In[5]:


rank_0_variable_1=tf.Variable("Elephant",tf.string)


# In[6]:


print(rank_0_variable_1)


# In[11]:


rank_0_var_2=tf.Variable(400,tf.int16)


# In[12]:


print(rank_0_var_2)


# In[13]:


floating_number=tf.Variable(3.147,tf.float64)
print(floating_number)


# In[14]:


complex_number=tf.Variable(12.3-4.2j,tf.complex64)
print(complex_number)


# In[15]:


example_1_rank_1=tf.Variable(["hello"],tf.string)
print(example_1_rank_1)


# In[32]:


example_2_rank_1=tf.Variable([[3.14,2.14]],tf.float32)
print(example_2_rank_1)


# In[33]:


complex_tensor_rank_1=tf.Variable([[12.3-4.8j,7.5-1.5j]],tf.complex64)
print(complex_tensor_rank_1)


# In[35]:


example_1_rank_2=tf.Variable([[7],[11]],tf.int16)
print(example_1_rank_2)


# In[36]:


image=tf.zeros([10,200,400,3])
print(image)


# In[37]:


print("Thanks")


# In[46]:


example_1_reshape=tf.ones([3,4,5])


# In[47]:


matrix=tf.reshape(example_1_reshape,[6,10])
print(matrix)
print(example_1_reshape)


# In[48]:


matrix_B=tf.reshape(matrix,[3,-1])
print(matrix_B)


# In[49]:


matrix_Alt=tf.reshape(matrix_B,[4,3,-1])


# In[50]:


print(matrix_Alt)


# In[51]:


error_example=tf.reshape(matrix_Alt,[13,2,-1])


# In[52]:


x=tf.placeholder(tf.float32,shape=(1024,1024),name="X_float")
print(x)


# In[54]:


y=tf.constant(1,dtype=tf.int32,shape=[24,1024],name="Alpha")
print(y)


# In[55]:


a=tf.constant(3.0,dtype=tf.float32)
b=tf.constant(4.0,dtype=tf.float32)
total=a+b
print(a)
print(b)
print(total)


# In[57]:


write=tf.summary.FileWriter('Folder_1')
write.add_graph(tf.get_default_graph())


# In[58]:


sess=tf.Session()
print(sess.run(total))


# In[60]:


print(sess.run({'ab':(a,b),'total':total}))


# In[78]:


x=tf.constant([[37,-23],[1.0,4.0]])
w=tf.Variable(tf.random_uniform([2,2]))
y=tf.matmul(x,w)
output=tf.nn.softmax(y)
init_op=w.initializer


# In[74]:


with tf.Session() as sess:
    sess.run(init_op)
    print(sess.run(output))
    y_val,output_val=sess.run([y,output])


# In[80]:


x=tf.placeholder(tf.float32)
y=tf.placeholder(tf.float32)
z=x+y
print(sess.run(z,feed_dict={x:3,y:4.5}))


# In[81]:


print(sess.run(z,feed_dict={x:[1,3],y:[2,4]}))


# In[84]:


x=tf.placeholder(tf.float32,shape=[None,3])
y=tf.layers.dense(x,units=1)

init=tf.global_variables_initializer()
sess.run(init)
print(sess.run(y,{x:[[1,2,3],[4,5,6]]}))

