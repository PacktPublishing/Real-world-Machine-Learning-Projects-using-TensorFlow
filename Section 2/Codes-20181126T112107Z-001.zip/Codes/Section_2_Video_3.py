
# coding: utf-8

# In[6]:


import tensorflow as tf
import numpy as np 
import matplotlib.pyplot as plt 
import scipy.io as sio 
import math 
rng=np.random
#parameters
learning_rate=0.01
training_epochs=1000
display_step=50
print("Imported sucessesfully")


# In[7]:


import tensorflow as tf
import numpy as np 
import matplotlib.pyplot as plt 
import scipy.io as sio 
import math 
rng=np.random
#parameters
learning_rate=0.01
training_epochs=1000
display_step=50
print("Imported sucessesfully")


# In[8]:


data_set=sio.loadmat('restaurant_profit.mat')


# In[9]:


import pandas as pd
data_sett=pd.read_csv('ML.csv')


# In[10]:


train_X=data_set['X1_one_var']
train_Y=data_set['Y1_one_var']


# In[11]:


plt.plot(train_X,train_Y,'bx')
plt.show()


# In[12]:


n_samples = train_X.shape[0]
X= tf.placeholder("float")
Y= tf.placeholder("float")

W=tf.Variable(rng.rand(),name="weight")
b=tf.Variable(rng.randn(),name="bias")

#the linear model 
pred=tf.add(tf.multiply(X,W),b)
n_samples=train_X.shape[0]
cost=tf.reduce_sum(tf.pow(pred-Y,2))/n_samples


# In[14]:


optimizer = tf.train.GradientDescentOptimizer(learning_rate).minimize(cost)
init=tf.global_variables_initializer()


# In[15]:


with tf.Session() as sess:
    
    sess.run(init)
    for epoch in range (training_epochs):
        for ( x,y) in zip ( train_X, train_Y):
            sess.run(optimizer,feed_dict={X:x,Y:y})
        if (epoch+1)% display_step ==0:
                c=sess.run(cost,feed_dict={X:train_X,Y:train_Y})
                print("Epoch_value:", '%04d' % (epoch+1), "cost_value=", "{:.9f}".format(c),                 "W=", sess.run(W), "b=", sess.run(b))
    print("Optimization Finished !")
    
    training_cost=sess.run(cost,feed_dict={X:train_X,Y:train_Y})
    print( "training_cost=", training_cost,"W=",sess.run(W),"b=",sess.run(b),'\n')
    writer=tf.summary.FileWriter('folderrr',sess.graph)
    writer.add_graph(sess.graph)
    writer.close()
    plt.plot(train_X, train_Y, 'ro', label='Original data')
    plt.plot(train_X, sess.run(W) * train_X + sess.run(b), label='Fitted line')
    plt.legend()
    plt.show()


# In[11]:


writer = tf.summary.FileWriter("output", sess.graph)
    print(sess.run(h))


# In[9]:


print ( "Gg")


# In[5]:


tf.VERSION

