
# coding: utf-8

# In[3]:


import numpy as np 
import pandas as pd 
import tensorflow as tf 
import math 
import shutil 
from IPython.core import display as ICD


# In[4]:


data_set=pd.read_csv("housing.csv")
print ( "Imported Successfully")


# In[5]:


data_set.head(15)


# In[6]:


a=pd.DataFrame(data_set.isnull().sum())
a['# of null values'] = a[0]
b = a[['# of null values']]


# In[7]:


print ( ' before Dropping Null Values : ')
print ( ' number of rows , columns : ', data_set.shape)


# In[8]:


ICD.display(b)


# In[9]:


data_set=data_set.dropna(axis=0)


# In[10]:


a=pd.DataFrame(data_set.isnull().sum())


# In[11]:


a['# of null values']=a[0]
b = a[['# of null values']]


# In[12]:


print ( "After Dropping null values: ")
print ( " # of rows, columns :", data_set.shape)


# In[13]:


ICD.display( b)


# In[14]:


data_set['num_rooms']=data_set['total_rooms']/data_set['households']
data_set['num_bedrooms']=data_set['total_bedrooms']/data_set['households']
data_set['persons_per_house']=data_set['population']/data_set['households']
data_set.drop(['total_rooms','total_bedrooms','population','households'],axis=1,inplace=True)


# In[15]:


data_set.head(10)


# In[16]:


featcols = {
  colname : tf.feature_column.numeric_column(colname) \
    for colname in 'housing_median_age,median_income,num_rooms,num_bedrooms,persons_per_house'.split(',')
}


# In[17]:


featcols['longitude'] = tf.feature_column.bucketized_column(tf.feature_column.numeric_column('longitude'),
                                                   np.linspace(-124.3, -114.3, 5).tolist())
featcols['latitude'] = tf.feature_column.bucketized_column(tf.feature_column.numeric_column('latitude'),
                                                  np.linspace(32.5, 42, 10).tolist())


# In[18]:


print((len(data_set)))


# In[19]:


mask=np.random.rand(len(data_set))<0.8


# In[20]:


print( mask)


# In[21]:


Training_data_set=data_set[mask]


# In[22]:


Eval_data_set=data_set[~mask]


# In[96]:


# Learning rate 0.3, 0.1, 0.03, 0.01
# batch_size 20-100
# num_epochs 1 - 50
scale = 100000
batch_size=30
num_epochs=50
learning_rate=0.03
NSteps=30000


# In[97]:


train_input_fn = tf.estimator.inputs.pandas_input_fn(x = Training_data_set[list(featcols.keys())],
                                                    y = Training_data_set["median_house_value"] / scale,
                                                    num_epochs = num_epochs,
                                                    batch_size = batch_size,
                                                    shuffle = True)


# In[98]:


Eval_input_fn=tf.estimator.inputs.pandas_input_fn(x=Eval_data_set[list(featcols.keys())],
                                                  y=Eval_data_set["median_house_value"]/scale,
                                                  num_epochs=num_epochs,
                                                  batch_size=len(Eval_data_set),
                                                  shuffle=False
)


# In[99]:


optimizer = tf.train.AdamOptimizer(learning_rate = learning_rate)


# In[100]:


# outdir='./foldere'


# In[101]:


model = tf.estimator.LinearRegressor(model_dir = outdir, feature_columns = featcols.values(), optimizer = optimizer )



# In[102]:



model.train(input_fn=train_input_fn, steps=NSteps)

